#include <iostream>
#include <string>
#include <cctype>

bool validateKeyLength(std::string const &key) {
    // key contains only 26 letters
    return key.length() == 26;
}

bool validateKeyOnlyLowercase(std::string const &key) {
    for(char c: key) {
        if(std::isupper(c)) {
            return false;
        }
    }
    return true;
}

bool validateContents(std::string const &key) {
    for(char letter = 'a'; letter <= 'z'; letter++) {
        if(key.find(letter) == std::string::npos) {
            return false;
        }
    }
    return true;

}

std:: string encrypt(std::string const &key, std::string const &plaintext) {
    std::string encryptedText = "";
    for(char letter : plaintext) {
        int index = letter - 'a';
        encryptedText += key.at(index);
    }
    return encryptedText;

}


int main()
{
    // get encryption
    std::string key;
    std::cout << "Enter the encryption key: ";
    std::getline(std::cin, key);

    // validate key length
    if(!validateKeyLength(key)) {
        std::cout << "Error! The encryption key must contain 26 characters." <<std::endl;
        return EXIT_FAILURE;
    }

    // validate only lowercase
    if(!validateKeyOnlyLowercase(key)){
        std::cout << "Error! The encryption key must contain only lower case characters." << std::endl;
        return EXIT_FAILURE;
    }

    // validate key contents
    if(!validateContents(key)) {
        std::cout << "Error! The encryption key must contain all alphabets a-z." << std::endl;
        return EXIT_FAILURE;
    }

    // encryption & printout the result
    std::string plaintext; // user input text to be encrypted
    std::cout << "Enter the text to be encrypted: ";
    std::getline(std::cin, plaintext);

    if(!validateKeyOnlyLowercase(plaintext)) {
        std::cout << "Error! The text to be encrypted must contain only lower case characters." << std::endl;
        return EXIT_FAILURE;
    }

    std::string encryptedText = encrypt(key, plaintext);
    std::cout << "Encrypted text: " << encryptedText << std::endl;

    return EXIT_SUCCESS;

}
