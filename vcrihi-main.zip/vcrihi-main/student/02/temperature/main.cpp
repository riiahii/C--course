#include <iostream>

using namespace std;

int main()
{
    double temperature = 0;
    std::cout << "Enter a temperature: ";
    std::cin >> temperature;

    std::cout << temperature << " degrees Celsius is " << temperature * 1.8 + 32 << " degrees Fahrenheit" << std::endl;
    std::cout << temperature << " degrees Fahrenheit is " << (temperature - 32) / 1.8  << " degrees Celsius" << std::endl;



    return 0;
}
