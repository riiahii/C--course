#include <iostream>

using namespace std;

int main()
{
    int n;
    cout << "Enter a number: ";
    cin >> n;

    // calculate number
    int cube = n*n*n;

    if(n == 0){
        cube = 0;
        cout << "The cube of " << n << " is " << cube << "." << endl;

    // check if cube is correct
    }else if(cube/n/n == n){
        cout << "The cube of " << n << " is " << cube << "." << endl;

    } else{
        cout << "Error! The cube of " << n << " is not " << cube << "." << endl;
        return EXIT_SUCCESS;
    }


}
