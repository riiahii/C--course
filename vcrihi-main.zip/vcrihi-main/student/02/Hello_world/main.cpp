#include <iostream>

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    cout << "Nollalla jako: " << 1/1 << endl;
    return 0;
}
