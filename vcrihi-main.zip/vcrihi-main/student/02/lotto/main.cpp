#include <iostream>

using namespace std;


int denominator(int a, int b) {
    unsigned long int numerator = 1;
        for(int i = 1; i <= a; ++i) {
            numerator *= i;
        }
        unsigned long int denominator = 1, df = 1, npf = 1;
        for(int j = 1; j <= b; ++j) {
            df *= j;
        }
        for(int k = 1; k <= (a-b); ++k) {
            npf *= k;
        }
        denominator = df * npf;



        return numerator / denominator;
}


int main() {

    int n1, n2;
    cout << "Enter the total number of lottery balls: ";
    cin >> n1;
    cout << "Enter the number of drawn balls: ";
    cin >> n2;

    if(n1 <= 0 || n2 <= 0){
        cout << "The number of balls must be a positive number." << endl;
    } else if(n1 < n2){
        cout << "The maximum number of drawn balls is the total amount of balls." << endl;
    } else {
        cout << "The probability of guessing all " << n2 << " balls correctly is 1/" << denominator(n1, n2)<< endl;
    }

}

