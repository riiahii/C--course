#include <iostream>

using namespace std;

int main()
{
    int number = 0;
    cout << "Enter a positive number: ";
    cin >> number;

    if(number <= 0){
        cout << "Only positive numbers accepted" << endl;
        return 0;
    }

    // find factors with shortest distance
    int smaller = 1, bigger = 1;

    for(int i = 1; i*i <= number; i++){
        if(number % i == 0){
            smaller = i;
        }
    }

    bigger = number / smaller;

    cout << number << " = " << smaller << " * " << bigger << endl;

}
