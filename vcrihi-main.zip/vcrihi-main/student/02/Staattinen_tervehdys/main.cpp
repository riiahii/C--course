#include <iostream>

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    bool b = 1 + 2;
    cout << b << endl;
    int i;

    if ( i = 0 ) {
        cout << "Hurraa" << endl;
    }
    return 0;
}
