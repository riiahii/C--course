Tähän hakemistoon kopioit koodipohjat templates-hakemistosta tai luot uudet ohjelmointiprojektit. Tänne voit myös kopioida examples-hakemiston koodit.

--------------------

In this directory, you will copy template codes from the directory called templates, or create new programming projects. You can also copy codes from the examples directory here.