#include <iostream>

using namespace std;

int main()
{
    cout << "Enter a positive number: ";

    // Write your code here

    return 0;
}
