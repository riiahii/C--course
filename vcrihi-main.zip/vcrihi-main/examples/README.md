Tähän hakemistoon kurssin henkilökunta tallentaa kurssimateriaaliin kuuluvia esimerkkikoodeja.

ÄLÄ TEE TÄHÄN HAKEMISTOON MITÄÄN MUUTOKSIA!

--------------------------------

In this directory, course personnel will store example codes of the course material.

DO NOT MAKE ANY MODIFICATIONS IN THIS DIRECTORY!
